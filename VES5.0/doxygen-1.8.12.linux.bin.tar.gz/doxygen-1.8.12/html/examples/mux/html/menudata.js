var menudata={children:[
{text:'Main Page',url:'index.html'},
{text:'Design Unit List',url:'annotated.html',children:[
{text:'Design Unit List',url:'annotated.html'},
{text:'Design Units',url:'classes.html'},
{text:'Design Unit Members',url:'functions.html',children:[
{text:'All',url:'functions.html'},
{text:'Variables',url:'functions_vars.html'}]}]},
{text:'Files',url:'files.html',children:[
{text:'File List',url:'files.html'}]}]}
